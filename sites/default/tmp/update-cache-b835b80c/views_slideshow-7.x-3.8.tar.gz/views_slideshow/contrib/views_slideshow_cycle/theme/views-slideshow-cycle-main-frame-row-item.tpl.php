<?php

/**
 * @file
 * Views Slideshow cycle: Main frame row item.
 *
 * - $classes: Classes.
 * - $item: Row item.
 *
 * @ingroup vss_templates
 */
?>
<div class="<?php print $classes; ?>">
  <?php print $item; ?>
</div>
